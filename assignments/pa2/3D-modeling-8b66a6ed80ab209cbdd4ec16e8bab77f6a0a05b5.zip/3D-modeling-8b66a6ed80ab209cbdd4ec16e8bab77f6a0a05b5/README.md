# 3D-modeling
OpenGL

the translate, rotation and scaling functions are implemented.

the final resule should be something like this:

![alt tag](https://github.com/w34ma/3D-modeling/blob/master/Capture.PNG)

![alt tag](https://github.com/w34ma/3D-modeling/blob/master/Capture1.PNG)

![alt tag](https://github.com/w34ma/3D-modeling/blob/master/Capture2.PNG)

![alt tag](https://github.com/w34ma/3D-modeling/blob/master/Capture4.PNG)
